package com.jobquest.backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JobQuestBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(JobQuestBackendApplication.class, args);
	}

}
