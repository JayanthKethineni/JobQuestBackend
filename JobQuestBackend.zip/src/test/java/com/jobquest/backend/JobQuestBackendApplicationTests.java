package com.jobquest.backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JobQuestBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
